var express = require("express");
var cors = require("cors");

var mongoose = require("mongoose");
mongoose.connect('mongodb://localhost/Cocina', {useNewUrlParser: true});

const calificaciones = new mongoose.Schema({
    nota: {type: Number, required:[true,'campo requerido']},
    comentario: {type:String, required:[true,'campo requerido'],maxlength:100}
})
const pasteles = new mongoose.Schema({
        pastelero: {type:String, required:[true,'campo requerido'],maxlength:50},
        imagen: {type:String, required:[true,'campo requerido'],maxlength:200},
        calificaciones: [calificaciones]
    },{timestamps:true})

const PAS = mongoose.model('pastel', pasteles);

var app = express();
app.use(cors());
app.use(express.json());
// app.use(express.urlencoded({extended:true}));

app.get('/', async function(req, res) {
    await PAS.find()
        .then(datos =>{
            if (datos.length===0){
                res.json({mensaje:"No Existen Datos"})
            } else {
                res.json(datos)
            }
        })
        .catch(err => res.json(err))
})

app.post('/', async function(req, res) {
    console.log(req.body)
    await PAS.create(req.body)
        .then(newper => {console.log(newper);res.json(newper)})
        .catch(err => res.json("PASO::" + err))
})
app.put('/:id', async function(req, res) {
    await PAS.updateOne({_id:req.params.id},req.body)
    .then(datos =>{(
        console.log(datos))
        if (datos === null){
            res.json({mensaje:"No Existe Dato"})
        } else {
           
            PAS.findOne({_id:req.params.id})
            .then(datos =>{
                if (datos === null){
                    res.json({mensaje:"No Existe Dato"})
                } else {
                    res.json(datos)
                }
            })
            .catch(err => res.json(err))

        }
    })
    .catch(err => res.json(err))    
})

app.put('/Comentario/:id', async function(req, res) {
    console.log("paso");
    console.log(req.params.id,req.body)
    await PAS.updateOne({_id:req.params.id},{$push:{calificaciones:req.body}})
    .then(datos =>{(
        console.log(datos))
        if (datos === null){
            res.json({mensaje:"No Existe Dato"})
        } else {
           
            PAS.findOne({_id:req.params.id})
            .then(datos =>{
                if (datos === null){
                    res.json({mensaje:"No Existe Dato"})
                } else {
                    res.json(datos)
                }
            })
            .catch(err => res.json(err))

        }
    })
    .catch(err => res.json(err))    
})

app.get('/:id', async function(req, res) {
    await PAS.findOne({_id:req.params.id})
    .then(datos =>{
        if (datos === null){
            res.json({mensaje:"No Existe Dato"})
        } else {
            res.json(datos)
        }
    })
    .catch(err => res.json(err))
})




// app.patch('/:id', function(req, res) {
//     TIT.updateOne({_id:req.params.id},req.body)
//     .then(datos =>{(
//         console.log(datos))
//         if (datos === null){
//             res.json({mensaje:"No Existe Dato"})
//         } else {
           
//             TIT.findOne({_id:req.params.id})
//             .then(datos =>{
//                 if (datos === null){
//                     res.json({mensaje:"No Existe Dato"})
//                 } else {
//                     res.json(datos)
//                 }
//             })
//             .catch(err => res.json(err))

//         }
//     })
//     .catch(err => res.json(err))    
// })

// app.delete('/:id', function(req, res) {
//     TIT.deleteOne({_id:req.params.id})
//         .then(res.json({mensaje:"Dato Eliminado"}))
//         .catch(err => res.json(err))
// })

app.listen(8000, function() {
    console.log("listening on port 8000");
})